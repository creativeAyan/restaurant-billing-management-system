<?php
/**
 * header.php
 * Safe version: ob_start() is the very first thing that runs.
 * This MUST be the first thing included on every page.
 */

// Step 1: Start output buffering IMMEDIATELY - before anything else
ob_start();

// Step 2: Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Step 3: Load config
require_once __DIR__ . '/config.php';

// Step 4: Auth check
requireLogin();

// Step 5: Page variables
$currentPage    = basename($_SERVER['PHP_SELF'], '.php');
$restaurantName = getSetting('restaurant_name') ?: 'Restaurant';
$flash          = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle ?? 'Dashboard') ?> - <?= sanitize($restaurantName) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <i class="fa-solid fa-utensils brand-icon"></i>
        <div>
            <div class="brand-name"><?= sanitize($restaurantName) ?></div>
            <div class="brand-sub">Billing System</div>
        </div>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-section">MAIN</div>
        <a href="<?= BASE_URL ?>dashboard.php" class="nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
            <i class="fa-solid fa-gauge-high"></i> Dashboard
        </a>
        <a href="<?= BASE_URL ?>modules/orders/new_order.php" class="nav-item <?= $currentPage === 'new_order' ? 'active' : '' ?>">
            <i class="fa-solid fa-plus-circle"></i> New Order
        </a>
        <a href="<?= BASE_URL ?>modules/orders/orders.php" class="nav-item <?= $currentPage === 'orders' ? 'active' : '' ?>">
            <i class="fa-solid fa-receipt"></i> All Orders
        </a>
        <a href="<?= BASE_URL ?>modules/billing/bills.php" class="nav-item <?= $currentPage === 'bills' ? 'active' : '' ?>">
            <i class="fa-solid fa-file-invoice-dollar"></i> Billing
        </a>

        <div class="nav-section">OPERATIONS</div>
        <a href="<?= BASE_URL ?>modules/tables/tables.php" class="nav-item <?= $currentPage === 'tables' ? 'active' : '' ?>">
            <i class="fa-solid fa-table-cells"></i> Tables
        </a>
        <a href="<?= BASE_URL ?>modules/reservations/reservations.php" class="nav-item <?= $currentPage === 'reservations' ? 'active' : '' ?>">
            <i class="fa-solid fa-calendar-check"></i> Reservations
        </a>
        <a href="<?= BASE_URL ?>modules/kitchen/kds.php" class="nav-item <?= $currentPage === 'kds' ? 'active' : '' ?>">
            <i class="fa-solid fa-fire-burner"></i> Kitchen Display
        </a>
        <a href="<?= BASE_URL ?>modules/delivery/delivery.php" class="nav-item <?= $currentPage === 'delivery' ? 'active' : '' ?>">
            <i class="fa-solid fa-motorcycle"></i> Delivery
        </a>
        <a href="<?= BASE_URL ?>modules/menu/menu.php" class="nav-item <?= $currentPage === 'menu' ? 'active' : '' ?>">
            <i class="fa-solid fa-book-open"></i> Menu
        </a>

        <div class="nav-section">CUSTOMERS</div>
        <a href="<?= BASE_URL ?>modules/customers/customers.php" class="nav-item <?= $currentPage === 'customers' ? 'active' : '' ?>">
            <i class="fa-solid fa-users"></i> Customers & Loyalty
        </a>
        <a href="<?= BASE_URL ?>modules/coupons/coupons.php" class="nav-item <?= $currentPage === 'coupons' ? 'active' : '' ?>">
            <i class="fa-solid fa-tag"></i> Coupons & Offers
        </a>

        <?php if (hasRole(['admin','manager'])): ?>
        <div class="nav-section">INVENTORY</div>
        <a href="<?= BASE_URL ?>modules/inventory/inventory.php" class="nav-item <?= $currentPage === 'inventory' ? 'active' : '' ?>">
            <i class="fa-solid fa-boxes-stacked"></i> Stock & Expenses
        </a>

        <div class="nav-section">REPORTS</div>
        <a href="<?= BASE_URL ?>modules/reports/analytics.php" class="nav-item <?= $currentPage === 'analytics' ? 'active' : '' ?>">
            <i class="fa-solid fa-chart-pie"></i> Analytics & P&L
        </a>
        <a href="<?= BASE_URL ?>modules/reports/sales.php" class="nav-item <?= $currentPage === 'sales' ? 'active' : '' ?>">
            <i class="fa-solid fa-chart-line"></i> Sales Report
        </a>
        <a href="<?= BASE_URL ?>modules/reports/daily.php" class="nav-item <?= $currentPage === 'daily' ? 'active' : '' ?>">
            <i class="fa-solid fa-calendar-day"></i> Daily Report
        </a>

        <div class="nav-section">ADMIN</div>
        <a href="<?= BASE_URL ?>modules/attendance/attendance.php" class="nav-item <?= $currentPage === 'attendance' ? 'active' : '' ?>">
            <i class="fa-solid fa-user-clock"></i> Attendance
        </a>
        <a href="<?= BASE_URL ?>modules/admin/staff.php" class="nav-item <?= $currentPage === 'staff' ? 'active' : '' ?>">
            <i class="fa-solid fa-user-tie"></i> Staff Management
        </a>
        <a href="<?= BASE_URL ?>modules/tables/manage_tables.php" class="nav-item <?= $currentPage === 'manage_tables' ? 'active' : '' ?>">
            <i class="fa-solid fa-chair"></i> Manage Tables
        </a>
        <a href="<?= BASE_URL ?>modules/menu/categories.php" class="nav-item <?= $currentPage === 'categories' ? 'active' : '' ?>">
            <i class="fa-solid fa-tags"></i> Categories
        </a>
        <a href="<?= BASE_URL ?>modules/admin/audit_log.php" class="nav-item <?= $currentPage === 'audit_log' ? 'active' : '' ?>">
            <i class="fa-solid fa-shield-halved"></i> Audit Log
        </a>
        <a href="<?= BASE_URL ?>settings.php" class="nav-item <?= $currentPage === 'settings' ? 'active' : '' ?>">
            <i class="fa-solid fa-gear"></i> Settings
        </a>
        <?php endif; ?>
    </nav>
    <div class="sidebar-user">
        <div class="user-avatar"><?= strtoupper(substr($_SESSION['user_name'] ?? 'U', 0, 1)) ?></div>
        <div class="user-info">
            <div class="user-name"><?= sanitize($_SESSION['user_name'] ?? '') ?></div>
            <div class="user-role"><?= ucfirst($_SESSION['user_role'] ?? '') ?></div>
        </div>
        <a href="<?= BASE_URL ?>logout.php" class="btn-logout" title="Logout"><i class="fa-solid fa-right-from-bracket"></i></a>
    </div>
</div>

<!-- Main Content -->
<div class="main-content" id="mainContent">
    <div class="topbar">
        <button class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="fa-solid fa-bars"></i>
        </button>
        <div class="topbar-title"><?= sanitize($pageTitle ?? 'Dashboard') ?></div>
        <div class="topbar-right">
            <div class="topbar-time" id="topbarTime"></div>
            <div class="topbar-date" id="topbarDate"></div>
        </div>
    </div>

    <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : ($flash['type'] === 'error' ? 'danger' : 'info') ?> alert-dismissible fade show mx-3 mt-3" role="alert">
        <?= sanitize($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="page-content">